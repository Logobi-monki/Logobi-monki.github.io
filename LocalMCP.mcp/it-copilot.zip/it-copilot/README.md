# IT Copilot

Focused coding assistant for Python, frontend, Linux, software design, code review, debugging, and algorithmic efficiency. The `coding` skill contains the workflow rules; `profile.json` stores the IT-specific preferences.

## Local MCP

Requires Node.js 20+. Run `cd server && npm install && npm test && npm start`. The stdio server exposes `get_profile`. Coding guidance is provided by the bundled skill.

## Cloud note

The package does not include a deployed cloud endpoint. To use MCP tools remotely, deploy an authenticated Streamable HTTP server and replace the stdio entry in `mcp.json` with its verified HTTPS endpoint.
