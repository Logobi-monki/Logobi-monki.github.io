import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const server = new McpServer({ name: 'it-copilot', version: '1.0.0' });
server.registerTool('get_profile', { title: 'Get IT profile', description: 'Read the current IT Copilot profile JSON.', inputSchema: {} }, async () => {
  const profile = JSON.parse(await readFile(path.join(ROOT, 'profile.json'), 'utf8'));
  return { content: [{ type: 'text', text: JSON.stringify(profile, null, 2) }] };
});
if ((process.env.COPILOT_TRANSPORT || 'stdio') !== 'stdio') throw new Error('This package currently supports stdio. Configure a separately hosted authenticated HTTP endpoint for cloud MCP.');
await server.connect(new StdioServerTransport());
