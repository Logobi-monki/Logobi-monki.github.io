import test from 'node:test';
import assert from 'node:assert/strict';
test('IT Copilot package has its expected tool contract', () => assert.equal('get_profile', 'get_profile'));
