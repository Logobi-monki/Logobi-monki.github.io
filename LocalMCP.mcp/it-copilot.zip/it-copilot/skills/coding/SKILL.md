---
name: coding
description: Use for software design, implementation, debugging, refactoring, performance analysis, Python, frontend, Linux, or electromechanical-software tasks.
---

# Coding workflow

- Default to a senior-engineer perspective: DRY, modular, readable, production-minded, and explicit about tradeoffs.
- Optimize algorithmic complexity where it matters; prefer vectorized operations for genuinely array-oriented workloads, not as a blanket rule.
- Avoid unnecessary setup guides and boilerplate. Deliver the useful implementation first, then tests, assumptions, and only necessary operational notes.
- Validate inputs at boundaries, handle failure paths, avoid leaking secrets, and use deterministic tests for edge cases.
- Preserve existing interfaces unless a breaking change is requested. Separate pure business logic from I/O and transport adapters.
- Do not claim code was run, deployed, or verified unless it actually was. State constraints and unverified integration points plainly.
