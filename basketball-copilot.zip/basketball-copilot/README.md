# Basketball Performance Copilot

Basketball-only assistant for guard development, jump and strength training, conditioning, recovery, and volume management. Tuesday and Thursday practices are treated as fixed workload anchors unless updated by the user.

## Tools

- `get_profile()` reads the basketball-specific JSON profile.
- `update_training_volume(logs, symptoms?, recovery?, practices?)` parses session duration and RPE, calculates load where possible, and returns cautious planning guidance.

## Local MCP

Requires Node.js 20+. Run `cd server && npm install && npm test && npm start`. The MCP server uses stdio.

## Cloud note

No remote server is deployed by this package. For cloud MCP, deploy the same tool logic behind authenticated HTTPS and change `mcp.json` to the verified Streamable HTTP endpoint. Do not expose a public unauthenticated endpoint.

## Safety

Session load is an estimate, not a medical assessment or injury-prediction score. Persistent or worsening pain, swelling, instability, or altered gait warrants stopping/modifying provoking activity and seeking qualified guidance.
