import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const server = new McpServer({ name: 'basketball-performance-copilot', version: '1.0.0' });
const profilePath = path.join(ROOT, 'profile.json');
server.registerTool('get_profile', { title: 'Get basketball profile', description: 'Read the current basketball profile and training constraints.', inputSchema: {} }, async () => {
  const profile = JSON.parse(await readFile(profilePath, 'utf8'));
  return { content: [{ type: 'text', text: JSON.stringify(profile, null, 2) }] };
});
server.registerTool('update_training_volume', {
  title: 'Review training volume',
  description: 'Parse training logs, estimate session load as duration minutes multiplied by session RPE, and give conservative guidance around Tuesday/Thursday practices. Not medical advice or an injury predictor.',
  inputSchema: {
    logs: z.string().min(1).describe('Training logs, ideally one per line, including duration in minutes and session RPE from 0 to 10.'),
    symptoms: z.string().optional().describe('Current pain, soreness, swelling, instability, or other symptoms.'),
    recovery: z.string().optional().describe('Sleep, energy, soreness, and recovery context.'),
    practices: z.string().optional().describe('Practice constraints; defaults to Tuesday and Thursday.')
  }
}, async ({ logs, symptoms = 'not provided', recovery = 'not provided', practices = 'Tuesday and Thursday' }) => {
  const parsed = String(logs).split(/\r?\n/).map(s => s.trim()).filter(Boolean).map((line, index) => {
    const durationMatch = line.match(/(?:duration|minutes?|mins?|min)\s*[:=]?\s*(\d+(?:\.\d+)?)/i) ?? line.match(/(\d+(?:\.\d+)?)\s*(?:minutes?|mins?|min)\b/i);
    const rpeMatch = line.match(/(?:s?RPE|RPE|effort)\s*[:=]?\s*(10|[0-9])(?:\s*\/\s*10)?\b/i);
    const duration = durationMatch ? Number(durationMatch[1]) : null;
    const rpe = rpeMatch ? Number(rpeMatch[1]) : null;
    const valid = Number.isFinite(duration) && duration > 0 && Number.isFinite(rpe) && rpe >= 0 && rpe <= 10;
    return { index: index + 1, log: line, duration_min: duration, rpe_0_to_10: rpe, session_load_au: valid ? Math.round(duration * rpe * 10) / 10 : null };
  });
  const valid = parsed.filter(x => x.session_load_au !== null);
  const symptomFlag = /pain|swelling|unstable|limp|worsen/i.test(symptoms) && !/no pain|pain.?0|none|no symptoms/i.test(symptoms);
  const result = {
    parsed_sessions: parsed,
    total_calculated_load_au: Math.round(valid.reduce((sum, x) => sum + x.session_load_au, 0) * 10) / 10,
    sessions_with_calculable_load: valid.length,
    practice_constraints_used: practices,
    readiness_inputs: { symptoms, recovery },
    interpretation: 'Session load = duration in minutes × session RPE. This is a rough internal-load estimate, not a validated injury-risk score or medical assessment.',
    recommendations: [
      'Treat Tuesday and Thursday practices as fixed workload anchors when planning the week.',
      'Avoid stacking large amounts of maximal jumping, sprinting, and heavy lower-body lifting on top of demanding practices without accounting for recovery.',
      'Progress one major workload variable at a time and use next-day symptoms, energy, and performance to guide adjustments.',
      'If readiness is uncertain, prefer a lower-volume technical or recovery session over forcing maximal output.'
    ],
    flags: [
      ...(valid.length < parsed.length ? ['Some log lines lack a recognizable duration and/or RPE; totals include only complete entries.'] : []),
      ...(valid.length === 0 ? ['No session-load total can be calculated. Include duration in minutes and RPE from 0–10.'] : []),
      ...(symptomFlag ? ['Symptoms may indicate pain or functional change. Avoid increasing provocative work and consider qualified clinical advice, especially if symptoms persist or worsen.'] : [])
    ]
  };
  return { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] };
});
if ((process.env.COPILOT_TRANSPORT || 'stdio') !== 'stdio') throw new Error('This package currently supports stdio. Configure a separately hosted authenticated HTTP endpoint for cloud MCP.');
await server.connect(new StdioServerTransport());
