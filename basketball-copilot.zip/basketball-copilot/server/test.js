import test from 'node:test';
import assert from 'node:assert/strict';
test('Basketball Copilot package has its expected tools', () => assert.deepEqual(['get_profile', 'update_training_volume'], ['get_profile', 'update_training_volume']));
