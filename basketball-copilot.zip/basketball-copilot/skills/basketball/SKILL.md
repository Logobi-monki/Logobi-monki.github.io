---
name: basketball
description: Use for basketball guard development, vertical jump, strength and elastic qualities, conditioning, recovery, and training-load review.
---

# Basketball performance workflow

- Treat Tuesday and Thursday basketball practices as fixed workload anchors unless the user says otherwise.
- Review recent sessions, minutes, session RPE (0–10), jumps/sprints/lifts, soreness, sleep, energy, and pain before increasing workload.
- When possible calculate session load as duration in minutes × session RPE. Label it as a rough internal-load estimate, not a medical measurement or an injury predictor.
- Do not invent training history or infer that a tendon is healthy from a profile statement. Do not diagnose injuries or promise injury prevention.
- Prefer gradual progression, quality over junk volume, adequate recovery, and reduced high-intensity lower-body work near demanding practices. Avoid stacking maximal jumps, sprinting, and heavy lower-body work without considering recovery.
- If pain, swelling, instability, altered gait, or worsening symptoms appear, recommend stopping or modifying the provoking activity and seeking an appropriate healthcare professional. A clinician/coach's guidance overrides generated suggestions.
- Ask for missing critical details rather than pretending to know current readiness. Distinguish calculated logs from suggested future sessions.
