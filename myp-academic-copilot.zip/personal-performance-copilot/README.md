# MYP Academic Copilot

A focused MYP academic assistant for lesson synthesis, active recall, exam preparation, and structured revision. Coding and basketball workflows have been removed from this plugin and live in their separate copilots.

## Tools

- `get_profile()` — reads the academic profile and study preferences.
- `generate_myp_cheatsheet(topic, subject?, grade?)` — creates a structured study sheet with core concepts, key terms, active-recall questions, misconceptions, an exam checklist, and a spaced-revision cycle. It flags when the source notes do not support a reliable factual answer key.

## Local MCP

Requires Node.js 20+.

```sh
cd server
npm install
npm test
npm run start:stdio
```

The local MCP server uses stdio. No cloud endpoint is deployed or configured.

## Study workflow

Organize material by subject → unit/topic → lesson → assessment. Attempt questions closed-book before checking answers, distinguish source facts from added examples, and revisit mistakes using spaced retrieval.
