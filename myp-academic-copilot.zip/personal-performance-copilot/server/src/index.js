import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { z } from 'zod';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '../..');
const PROFILE_PATH = path.join(ROOT, 'profile.json');

async function loadProfile() {
  return JSON.parse(await readFile(PROFILE_PATH, 'utf8'));
}

function buildCheatsheet(topic, subject = 'Not specified', grade = 'Not specified') {
  const clean = String(topic ?? '').trim();
  if (!clean) throw new Error('topic must contain lesson notes or a topic to study');
  const chunks = clean.split(/\n+/).map(x => x.trim()).filter(Boolean);
  const keyTerms = [...new Set((clean.match(/\b[A-Z][A-Za-z-]{3,}|\b[A-Za-z-]{7,}\b/g) ?? []))].slice(0, 12);
  return {
    title: `MYP Study Sheet — ${subject}`,
    subject,
    grade_or_year: grade,
    topic: chunks[0].slice(0, 180),
    source_note: 'Generated from the provided text. When input is brief, prompts are scaffolds rather than claims about missing curriculum content.',
    core_concepts: chunks.slice(0, 10),
    key_terms: keyTerms,
    worked_example: 'Add a worked example from class or create one that demonstrates the central process. Do not treat this placeholder as a subject-specific worked solution.',
    common_misconceptions: ['Confusing memorizing a definition with being able to explain or apply it.', 'Skipping intermediate reasoning steps in an explanation or calculation.'],
    active_recall_questions: [
      `Define the central idea in your own words: ${chunks[0].slice(0, 180)}`,
      'What are the 3–5 most important facts, steps, or principles, and why do they matter?',
      'Explain one connection between this topic and a previously learned concept.',
      'Apply the idea to a new example. Show each reasoning step.',
      'What is a common misconception, and how would you correct it?',
      'Which part can you recall without looking at your notes, and which part needs another review?'
    ],
    answer_key: ['Answer from memory first, then compare with the source notes. The provided input may not contain enough verified detail for a reliable factual answer key; do not infer unsupported facts.'],
    exam_checklist: ['I can define key terms without notes.', 'I can explain the main concept and why it works.', 'I can solve or analyze a new example.', 'I can justify my answer using evidence, steps, or subject vocabulary.', 'I have revisited mistakes using spaced retrieval.'],
    suggested_revision_cycle: ['Attempt questions closed-book.', 'Check notes and correct missing or inaccurate points.', 'Retry missed questions later the same day.', 'Retry again after 1–3 days.']
  };
}

export function createServer() {
  const server = new McpServer({ name: 'myp-academic-copilot', version: '1.1.0' });
  server.registerTool('get_profile', {
    title: 'Get academic profile',
    description: 'Read the local academic profile and MYP study preferences.',
    inputSchema: {}
  }, async () => ({ content: [{ type: 'text', text: JSON.stringify(await loadProfile(), null, 2) }] }));
  server.registerTool('generate_myp_cheatsheet', {
    title: 'Generate MYP active-recall study sheet',
    description: 'Turn provided lesson notes or a topic into a structured MYP revision sheet with concepts, terms, active recall, misconceptions, an answer-key caveat, and an exam checklist. Does not invent unsupported facts.',
    inputSchema: {
      topic: z.string().min(1).describe('Lesson notes or topic text.'),
      subject: z.string().optional().describe('MYP subject, if known.'),
      grade: z.string().optional().describe('MYP year or grade, if known.')
    }
  }, async ({ topic, subject, grade }) => ({ content: [{ type: 'text', text: JSON.stringify(buildCheatsheet(topic, subject, grade), null, 2) }] }));
  return server;
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  const server = createServer();
  await server.connect(new StdioServerTransport());
}
