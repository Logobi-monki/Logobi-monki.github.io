import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from './src/index.js';

test('academic MCP server can be constructed', () => {
  const server = createServer();
  assert.ok(server);
});
