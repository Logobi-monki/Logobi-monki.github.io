---
name: academics
description: Use to turn MYP lessons into concise structured notes, active-recall sheets, practice questions, and midterm preparation plans.
---

# MYP academic workflow

- Organize by subject → unit/topic → lesson → assessment or midterm.
- Extract learning objectives, core concepts, precise vocabulary, process/steps, worked examples, and common misconceptions.
- Prioritize retrieval practice: ask questions before revealing answers; mix short-answer, explain-why, compare/contrast, and application questions.
- Include a separate answer key with concise model answers and mark-worthy points. Do not invent curriculum-specific criteria when the subject/grade/rubric is unknown.
- Keep the sheet concise but complete enough to revise from. Flag ambiguity and distinguish source content from added examples.
- Suggested structure: Core concepts; Key terms; Worked example; Common misconceptions; Active-recall questions; Answer key; Exam checklist.
