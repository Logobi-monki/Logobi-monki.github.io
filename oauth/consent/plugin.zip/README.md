# MYP Academic Copilot — v1.5.1

A student-centered school copilot for MYP/PEI students, with focused workflows for PÉI projects, authentic reflections, writing and revision, references/cover pages using the supplied French school guide, workload planning, and a persistent authenticated school workspace.

## Included workflows

- `academics`: lesson synthesis, explanation, active recall, study sheets, exam preparation, and assignment routing.
- `pei-project`: decode the brief, build a plan, track research/evidence, review progress, and check the final deliverable against the actual rubric.
- `pei-reflection`: coach the student's own reflection through experience, actions, evidence, learning, evaluation, and next steps without inventing personal details.
- `writing-coach`: outline, draft from student-provided ideas, revise, and proofread in French or English while preserving the student's voice.
- `apa-references`: apply the supplied school handout's French APA-style patterns and create a cover-page template; flag missing source information.
- `school-planner`: organize tasks, milestones, deadlines, and weekly workload; use the authenticated workspace tools when available.

## Persistent school workspace

The private plugin now declares the Streamable HTTP MCP endpoint:

`https://ueqqoyhtwnfhggrefyxq.supabase.co/functions/v1/school-workspace`

The endpoint is deployed as Supabase Edge Function `school-workspace` (version 5) and registers these tools:

- `get_profile` — verify which account is connected.
- `list_records` — list subjects, assignments, grades, study sessions, PEI/MYP projects, profile, or preferences.
- `upcoming_deadlines` — retrieve incomplete assignments by due date.
- `create_record`, `update_record`, `delete_record` — manage school records with per-table field allowlists.

The endpoint uses Supabase Auth user context and the database's row-level security (RLS), so each call should act as the authenticated user. Writes do not accept a caller-selected owner id. Profile and preference rows are treated as per-user singletons. The function's built-in Edge JWT gate is disabled to allow OAuth metadata discovery, while its `withOAuthProtectedResource()` and `withSupabase({ auth: "user" })` middleware enforce the actual authenticated request path.

## One-time Supabase Auth setup still required

The server and client connection configuration are present, but the OAuth path has **not yet been end-to-end tested** and may not work until these dashboard settings are enabled:

1. In Supabase Dashboard → Authentication → OAuth Server, enable OAuth 2.1 and Dynamic Client Registration; set the Authorization Path to `/oauth/consent`.
2. In Authentication → URL Configuration, set Site URL to `https://logobi-monki.github.io` and allow the consent URL as a redirect URL where applicable.
3. Follow Supabase's current guidance for an asymmetric JWT signing key (ES256 or RS256) before using the OAuth/OIDC flow. Avoid changing active signing keys without reviewing any existing clients/sessions.
4. Open the plugin in ChatGPT, complete the OAuth connection, then test `get_profile`, `list_records`, and a reversible create/update/delete on a test record before relying on saved data.

The static consent/sign-in page is at `https://logobi-monki.github.io/oauth/consent/`. It uses only the public Supabase publishable key. This page was committed to GitHub, but its live GitHub Pages URL and OAuth flow could not be remotely verified from this runtime. If GitHub Pages is not enabled for the repository, enable it for the `main` branch root.

## Security and reliability

- Never place service-role/secret keys, OAuth client secrets, or user access/refresh tokens in this plugin, a browser page, chat, or a public repository.
- Do not report a record as saved unless a connected MCP tool confirms success.
- The database security advisor returned no findings at the most recent check. Performance notices are unused-index informational items on a new, not-yet-exercised schema.
- The connection is a release/configuration step, not proof of an end-to-end successful OAuth session; verify it in ChatGPT before relying on persistent behavior.
