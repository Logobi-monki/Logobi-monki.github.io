---
name: apa-references
description: Use when an MYP/PEI student needs citations, a bibliography, source classification, the supplied French APA-style school guide, or a school assignment cover page.
---

# References and Cover Pages — School Guide

Use the student's school handout as the governing formatting reference for the assignment. The supplied handout is a French APA-style guide organized around Auteur–Date–Titre–Source (« Qui–Quand–Quoi–Où »). It may differ from current APA editions; do not silently replace teacher/school instructions with a different edition. If the user asks for the current official APA style, distinguish that request and verify the applicable edition.

## Reference-building workflow

1. Identify the source type: journal article, electronic journal article, book, book chapter, ebook, electronic book chapter, web document/page, government report, or dictionary/encyclopedia entry.
2. Collect the available fields: author or organization; date/year; title; container/source; volume/issue/pages; edition/editor/chapter pages; publisher or place when the handout requests it; DOI or URL; and format label if required.
3. Never invent a missing author, date, title, DOI, page range, publisher, or URL. Use a clear `[information missing]` note and ask for it when necessary.
4. Format a reference using the relevant pattern below. Preserve the language, accents, capitalization, and source details accurately.
5. Check alphabetical order, consistent italics, punctuation, completeness, and that in-text citations match the reference list when in-text citations are requested.
6. Make uncertainty explicit: a plausible-looking reference is not evidence that a source exists. Verify DOI/URL/source metadata when web access is available.

## Patterns transcribed from the supplied school handout

These patterns represent the **school handout provided by the student**, not a claim that every detail is identical to the latest APA edition.

- **Article:** Author(s). (Year). Article title. *Journal title, volume*(issue), page range.
- **Electronic journal article:** Author(s). (Year). Article title. *Journal title, volume*(issue), page range. DOI or URL, following the school handout's rule.
- **Book:** Author(s). (Year). *Book title* (edition, if applicable). Place of publication: Publisher.
- **Book chapter:** Chapter author(s). (Year). Chapter title. In Editor(s) (Ed./Eds. or the French form « dir. » as instructed), *Book title* (edition/volume, page range). Place of publication: Publisher.
- **Ebook:** Author/organization. (Year). *Book title* (edition, if applicable). DOI or URL; include a format note such as `[version en fichier PDF]` only when required by the handout.
- **Electronic book chapter:** Chapter author(s). (Year). Chapter title. In Editor(s) (dir.), *Book title* (edition/volume, page range). DOI or URL.
- **Web document/page:** Author or organization. (Year/date). *Document title* [PDF or HTML format, when applicable]. Retrieved from / Repéré à URL, following the handout.
- **Government report:** Ministry or organization. (Year). *Title: Subtitle* (Publication number, if available). Place of publication: Publisher/author, when the report was consulted in paper form and the school handout requires it.
- **Dictionary/encyclopedia entry:** Entry author. (Year). Entry title. In Editor(s) (dir.), *Encyclopedia title* (volume, page range). Place of publication: Publisher.

Use the exact examples the student supplied as patterns for punctuation and French-language labels if needed. Since the source text only includes one handout, do not claim to know any additional school-specific rules.

## In-text citations

When the assignment calls for in-text citations, help connect each borrowed idea, paraphrase, or quotation to a matching reference entry. Ask which source supports a claim if it is unclear. Do not create page numbers for quotations or invent source details. Follow teacher instructions for direct quotations, page numbers, and web sources.

## Cover page template from the supplied handout

Create a fill-in template with the following fields and approximate order:

**[TITLE OF THE ASSIGNMENT]**

Travail présenté à : Monsieur / Madame [nom de l’enseignant·e]

Dans le cadre du cours : [nom du cours]

Par : [nom de l’élève]

Groupe : [XX]

École la Courvilloise

[date de remise]

Do not fill personal or teacher details by guessing. Keep the template easy to adapt if the teacher supplied a different required format.
