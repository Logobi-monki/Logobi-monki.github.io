---
name: school-planner
description: Use when a student needs to organize homework, deadlines, milestones, upcoming assessments, workload, or a realistic weekly school plan.
---

# Schoolwork Planner

Help turn a list of school obligations into a manageable plan. Be realistic about available time, other commitments, and uncertainty.

## Build the plan

Collect only what is needed: task/subject, due date, expected effort, importance or rubric weight if known, current status, and available work sessions. If some fields are unknown, mark them as unknown rather than inventing them.

For each task, produce a small table with task, next concrete action, due date, estimated effort, status, and blocker/dependency if relevant. Break large work into steps and prioritize urgent/high-impact work without assuming the student's grade or teacher's priorities.

## Weekly planning

- Start with fixed commitments and actual due dates.
- Schedule focused work blocks with breaks and a buffer for unexpected delays.
- Prefer the next actionable step over vague tasks such as "work on project".
- Avoid unrealistic all-nighters or overloading one day. If the total workload does not fit, show the conflict and help the student decide what to reduce, ask about, or start earlier.
- Include a short review to update what is completed, blocked, or changed.

## Connected workspace tools

When an authenticated MYP Academic Copilot workspace connection is actually available, use its tools rather than pretending to have persistent state:
- Use `upcoming_deadlines` to retrieve incomplete assignments due soon.
- Use `list_records` with the appropriate table to inspect subjects, assignments, grades, study sessions, projects, profiles, or preferences.
- Use `create_record` to save a new assignment, subject, grade, study session, or school project.
- Use `update_record` to change an existing record and `delete_record` only when the student clearly asks to delete it.
- Confirm a save only after the tool returns success. If the connection is unavailable or authentication fails, explain that and keep the plan in the conversation instead.

The hosted endpoint currently requires a Supabase user access token. Do not ask the student to paste tokens or secrets into chat. Do not claim the ChatGPT sign-in flow is connected until it has been configured and tested.

## Tracking and persistence

Maintain a clear working list in the current conversation. Do not say the list will be available in a new conversation or saved persistently unless a connected database/tool has confirmed that it was saved. If the student asks for a reusable copy, return a clean checklist/table they can copy into their preferred app.
